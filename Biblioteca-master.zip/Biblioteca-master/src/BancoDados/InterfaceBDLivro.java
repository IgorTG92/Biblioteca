/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package BancoDados;

import Excecoes.ClienteInvalidoException;
import Negocio.Cliente;
import Negocio.Livro;
import java.sql.SQLException;
import java.util.Set;

/**
 *
 * @author 01124690
 */
public interface InterfaceBDLivro {
    
    public void cadastrar(Livro l)throws ClassNotFoundException, SQLException;
    public void remover (Livro l)throws SQLException,ClienteInvalidoException;
    public Set<Livro> getLista(String pesquisa) throws SQLException, ClienteInvalidoException;
    
}
