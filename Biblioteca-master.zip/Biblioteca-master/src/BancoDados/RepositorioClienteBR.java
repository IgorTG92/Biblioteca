/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BancoDados;

import Excecoes.ClienteContainsException;
import Excecoes.ClienteInvalidoException;
import Negocio.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Win7
 */
public class RepositorioClienteBR implements InterfaceBDCliente {

    private Connection conexao;

    public RepositorioClienteBR() throws SQLException, ClassNotFoundException {
        this.conexao = Conexao.conectar();

    }

    @Override
    public void cadastrar(Cliente c) throws ClassNotFoundException, SQLException {

        String insert = "insert into cliente (nome_cliente, cpf_cliente, endereco_cliente,email_cliente, telefone_cliente)";

        PreparedStatement stmt = conexao.prepareStatement(insert);

        stmt.setString(1, c.getNome());
        stmt.setString(2, c.getCpf());
        stmt.setString(3, c.getEndereco());
        stmt.setString(4, c.getEmail());
        stmt.setString(5, c.getTelefone());

        stmt.execute();
        stmt.close();
    }

    @Override
    public void remover(Cliente c) throws SQLException,ClienteInvalidoException {

        String remover = "delete from cliente where cpf_cliente";

        PreparedStatement stmt = conexao.prepareStatement(remover);

        stmt.setString(1, c.getCpf());
        stmt.execute();
        stmt.close();
    }

    @Override
    public Set<Cliente> getLista(String pesquisa) throws SQLException, ClienteInvalidoException {

        String sql = "select * from cliente where nome_cliente";
        PreparedStatement stmt = conexao.prepareStatement(sql);
        stmt.setString(1, pesquisa);
        ResultSet rs = stmt.executeQuery();

        Set<Cliente> clientes = new HashSet<Cliente>();

        while (rs.next()) {

            Cliente c = new Cliente();

            c.setNome(rs.getString("nome_cliente"));
            c.setCpf(rs.getString("cpf_cliente"));
            c.setEndereco(rs.getString("endereco_cliente"));
            c.setEmail(rs.getString("email_cliente"));
            c.setTelefone(rs.getString("telefone_cliente"));
        }

        rs.close();
        stmt.close();
        return clientes;
    }

}
