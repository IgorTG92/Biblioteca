/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Excecoes.LivroContainsException;
import Negocio.Livro;

/**
 *
 * @author Win7
 */
public interface InterfaceLivro {
    
    public void cadastrar(Livro l)throws LivroContainsException;
    public void remover (Livro l)throws LivroContainsException;
    public void listar();
    
}
