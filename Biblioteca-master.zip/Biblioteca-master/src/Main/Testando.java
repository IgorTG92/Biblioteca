/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Excecoes.ClienteContainsException;
import Excecoes.ClienteInvalidoException;
import Excecoes.FuncionarioContainsException;
import Excecoes.FuncionarioInvalidoException;
import Excecoes.LivroContainsException;
import Excecoes.LivroInvalidoException;
import Interface.RepCliente;
import Interface.RepFuncionario;
import Interface.RepLivro;
import Interface.TelaPrincipal;
import Negocio.Cliente;
import Negocio.Funcionario;
import Negocio.Livro;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Win7
 */
public class Testando {

    public static void main(String[] args) throws LivroInvalidoException {

        TelaPrincipal tp = new TelaPrincipal();
        tp.setVisible(true);

        Cliente c = null;
        RepCliente rc = new RepCliente();
        RepFuncionario rf = new RepFuncionario();
        RepLivro rl = new RepLivro();
        Funcionario f = null;
        Livro l = null;
        String nome = null, email = null, telefone = null, cpf, endereco = null, genero = null, profissao = null;
        double valor = 0;
        int codigo = 0, opcao = 0, qtdPaginas = 0;

        Scanner entrada = new Scanner(System.in);

        System.out.println("MENU DOS CLIENTES!");
        do {
            System.out.println("1 - CADASTRAR CLIENTE!");
            System.out.println("2 - REMOVER CLIENTE!");
            System.out.println("3 - LISTAR CLIENTES!");
            System.out.println("5 - SAIR!");

            opcao = entrada.nextInt();
            entrada.nextLine();

            switch (opcao) {
                case 1:
                    System.out.println("INFORME O NOME");
                    nome = entrada.nextLine();

                    System.out.println("INFORME O CPF");
                    cpf = entrada.nextLine();

                    System.out.println("INFORME O ENDEREÇO");
                    endereco = entrada.nextLine();

                    System.out.println("INFORME SEU E-MAIL");
                    email = entrada.nextLine();

                    System.out.println("INFORME O TELEFONE");
                    telefone = entrada.nextLine();

                    try {
                        c = new Cliente(nome, cpf, endereco, email, telefone);
                        rc.cadastrar(c);
                    } catch (ClienteContainsException | ClienteInvalidoException ex) {
                        System.out.println(ex.getMessage());
                    }
                    break;

                case 2:

                    System.out.println("INFORME O NOME");
                    nome = entrada.nextLine();

                    System.out.println("INFORME O CPF");
                    cpf = entrada.nextLine();
                    try {
                        c = new Cliente(nome, cpf, endereco, email, telefone);
                        rc.remover(c);
                    } catch (ClienteContainsException | ClienteInvalidoException ex) {
                        System.out.println(ex.getMessage());
                    }
                    break;

                case 3:
                    rc.listar();
                    break;
                case 5:
                    System.out.println("((((VOCÊ SAIU DO MENU!))))");
                    break;
                default:
                    System.out.println("Digite uma opção correta!");
                    break;

            }

        } while (opcao != 5);

        System.out.println("");

        System.out.println("MENU DOS LIVROS!");

        do {
            System.out.println("1 - CADASTRAR LIVRO");
            System.out.println("2 - REMOVER LIVRO");
            System.out.println("3 - LISTAR LIVROS");
            System.out.println("5 - SAIR!");

            opcao = entrada.nextInt();
            entrada.nextLine();

            switch (opcao) {
                case 1:
                    System.out.println("INFORME O NOME DO LIVRO!");
                    nome = entrada.nextLine();

                    System.out.println("INFORME O GÊNERO!");
                    genero = entrada.nextLine();

                    System.out.println("INFORME O CÓDIGO!");
                    codigo = entrada.nextInt();
                    entrada.nextLine();

                    System.out.println("INFORME O VALOR!");
                    valor = entrada.nextDouble();
                    entrada.nextLine();

                    System.out.println("INFORME TOTAL DE PÁGINAS!");
                    qtdPaginas = entrada.nextInt();
                    entrada.nextLine();

                    try {
                        l = new Livro(nome, genero, codigo, valor, qtdPaginas);
                        rl.cadastrar(l);
                    } catch (LivroInvalidoException | LivroContainsException ex) {
                        System.out.println(ex.getMessage());
                    } finally {
                        System.out.println("LIVRO CADASTRADO COM SUCESSO!");
                    }
                    break;

                case 2:
                    System.out.println("INFORME O NOME DO LIVRO!");
                    nome = entrada.nextLine();

                    System.out.println("INFORME O CÓDIGO!");
                    codigo = entrada.nextInt();
                    entrada.nextLine();

                    try {
                        l = new Livro(nome, genero, codigo, valor, qtdPaginas);
                        rl.remover(l);
                    } catch (LivroInvalidoException | LivroContainsException ex) {
                        System.out.println(ex.getMessage());
                    } finally {
                        System.err.println("LIVRO REMOVIDO COM SUCESSO!");
                    }
                    break;
                case 3:
                    rl.listar();
                    break;
                case 5:
                    System.out.println("((((VOCÊ SAIU DO MENU!))))");
                    break;
                default:
                    System.out.println("Digite uma opção correta!");
                    break;

            }

        } while (opcao != 5);

        System.out.println("");
        System.out.println("MENU DOS FUNCIONÁRIOS!");

        do {
            System.out.println("1 - CADASTRAR FUNCIONÁRIO!");
            System.out.println("2 - REMOVER FUNCIONÁRIO!");
            System.out.println("3 - LISTAR FUNCIONÁRIOS!");
            System.out.println("5 - SAIR");

            opcao = entrada.nextInt();
            entrada.nextLine();

            switch (opcao) {
                case 1:
                    System.out.println("INFORME O NOME DO FUNCIONÁRIO!");
                    nome = entrada.nextLine();

                    System.out.println("INFORME O CÓDIGO!");
                    codigo = entrada.nextInt();
                    entrada.nextLine();

                    System.out.println("INFORME A PROFISSÃO!");
                    profissao = entrada.nextLine();

                    try {
                        f = new Funcionario(nome, codigo, profissao);
                        rf.cadastrar(f);
                    } catch (FuncionarioContainsException | FuncionarioInvalidoException ex) {
                        System.err.println(ex.getMessage());
                    } finally {
                        System.out.println("FUNCIONÁRIO CADASTRADO COM SUCESSO!!");
                    }
                    break;
                case 2:
                    System.out.println("INFORME O NOME DO FUNCIONÁRIO!");
                    nome = entrada.nextLine();

                    System.out.println("INFORME O CÓDIGO!");
                    codigo = entrada.nextInt();
                    entrada.nextLine();

                    try {
                        f = new Funcionario(nome, codigo, profissao);
                        rf.remover(f);
                    } catch (FuncionarioContainsException | FuncionarioInvalidoException ex) {
                        System.err.println(ex.getMessage());
                    } finally {
                        System.out.println("FUNCIONÁRIO REMOVIDO COM SUCESSO!!");
                    }
                    break;

                case 3:
                    rf.listar();
                    break;
                case 5:
                    System.out.println("(((VOCÊ SAIU DO MENU)))");
                    break;
                default:
                    System.out.println("DIGITE UMA OPÇÃO CORRETA");
                    break;

            }

        } while (opcao != 5);

    }

}
