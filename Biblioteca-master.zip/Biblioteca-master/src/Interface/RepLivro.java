/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Excecoes.LivroContainsException;
import Negocio.Livro;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Win7
 */
public class RepLivro implements InterfaceLivro {

    private Set<Livro> livros;

    public RepLivro() {
        this.livros = new HashSet<Livro>();
    }

    @Override
    public void cadastrar(Livro l) throws LivroContainsException {
        if (this.livros.contains(l)) {
            throw new LivroContainsException("LIVRO JÁ CADASTRADO!");
        } else {
            this.livros.add(l);
        }
    }

    @Override
    public void remover(Livro l) throws LivroContainsException {
        if (this.livros.contains(l)) {
            this.livros.remove(l);
        } else {
            throw new LivroContainsException("LIVRO JÁ CADASTRADO!");
        }
    }

    @Override
    public void listar() {
        for (Livro l : this.livros) {
            System.out.println(l.toString());
        }
    }

}
