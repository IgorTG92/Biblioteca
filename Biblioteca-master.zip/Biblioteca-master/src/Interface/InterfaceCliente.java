/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Excecoes.ClienteContainsException;
import Negocio.Cliente;

/**
 *
 * @author Win7
 */
public interface InterfaceCliente {
    
    public void cadastrar(Cliente c)throws ClienteContainsException;
    public void remover (Cliente c)throws ClienteContainsException;
    public void listar();
    
}
