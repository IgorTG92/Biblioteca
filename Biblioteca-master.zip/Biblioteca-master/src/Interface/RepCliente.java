/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interface;

import Excecoes.ClienteContainsException;
import Negocio.Cliente;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author Win7
 */
public class RepCliente implements InterfaceCliente {

    private Set<Cliente> clientes;

    public RepCliente() {
        this.clientes = new HashSet<Cliente>();
    }

    @Override
    public void cadastrar(Cliente c) throws ClienteContainsException {
        if (this.clientes.contains(c)) {
            throw new ClienteContainsException("CLIENTE JÁ CADASTRADO!");
        } else {
            this.clientes.add(c);
        }
    }

    @Override
    public void remover(Cliente c) throws ClienteContainsException {
        if (this.clientes.contains(c)) {
            this.clientes.remove(c);
        } else {
            throw new ClienteContainsException("CLIENTE JÁ REMOVIDO!");
        }
    }

    @Override
    public void listar() {
        for (Cliente c : this.clientes) {
            System.out.println(c.toString());
        }
    }

}
